package com.example.calculator;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

public class HelloController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button Division;

    @FXML
    private Button Multiplication;

    @FXML
    private Button Subtraction;

    @FXML
    private TextField TextField;

    @FXML
    private Button addition;

    @FXML
    private Button btn0;

    @FXML
    private Button btn1;

    @FXML
    private Button btn2;

    @FXML
    private Button btn3;

    @FXML
    private Button btn4;

    @FXML
    private Button btn5;

    @FXML
    private Button btn7;

    @FXML
    private Button btn8;

    @FXML
    private Button btn9;

    @FXML
    private Button equals;

    @FXML
    void handleEqualsButton(ActionEvent event) {

    }

    @FXML
    void handleNumberButton(ActionEvent event) {

    }

    @FXML
    void handleOperationButton(ActionEvent event) {

    }

    @FXML
    void initialize() {


    }

}
